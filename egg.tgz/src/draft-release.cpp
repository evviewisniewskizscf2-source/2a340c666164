// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("draft release"); }
int main(){
  announce();
  return lionss_run_workload("draft-release");
}
