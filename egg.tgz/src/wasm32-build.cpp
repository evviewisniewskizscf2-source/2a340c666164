// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("wasm32 build\n", stdout);
  return lionss_run_workload("wasm32-build");
}
