// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("trivy scan\n", stdout);
  return lionss_run_workload("trivy-scan");
}
