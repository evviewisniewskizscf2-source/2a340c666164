// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("rpath check"); }
int main(){
  announce();
  return lionss_run_workload("rpath-check");
}
