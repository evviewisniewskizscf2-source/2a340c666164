// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("slsa provenance"); }
int main(){
  announce();
  return lionss_run_workload("slsa-provenance");
}
